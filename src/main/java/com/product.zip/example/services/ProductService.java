package com.example.services;

import com.example.domain.Product;

public interface ProductService {

	Iterable<Product> listAllProducts();
	
	Product getProductById(Long id);
	Product saveProduct(Product product);
	void deleteProduct(Long id);
}
